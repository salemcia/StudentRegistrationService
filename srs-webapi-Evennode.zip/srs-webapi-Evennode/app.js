const express = require('express');
const cors = require('cors');
const mongoClient = require('mongodb').MongoClient;

const app = express();
app.use(cors());


const bodyParser = require('body-parser'); //read form data and form fields


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
//STEP 1: npm install method-override
const methodOverride = require('method-override'); //to support PUT and DELETE FROM browssers
app.use(methodOverride('_method'));
const mongoServerURL = "mongodb+srv://admin:admin@clustersrs.eulij.mongodb.net/srsDB?retryWrites=true&w=majority";


//default route / - display all info
app.get('/', (request, response, next) => {
    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //read from  collection
        srsDB.collection("tblstudent").find({},{_id:0}).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        //db.close();
    });

});




//get a student by StudentID - used in update and delete web pages
app.get('/StudentID/:StudentID', (request, response, next) => {

    let studentID = request.params.StudentID;

    studentID = parseInt(studentID);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {StudentID:studentID};


        //read from  collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});



//get a student by StudentName - used in update and delete web pages
app.get('/StudentName/:StudentName', (request, response, next) => {

    const studentName = request.params.StudentName;

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {StudentName:studentName};


        //read from   collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});


//get students by Program - used in update and delete web pages
app.get('/byProgram/:Program', (request, response, next) => {

    const program = request.params.Program;

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {Program:program};


        //read from  collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});



//get a students by Acadmicyear - used in update and delete web pages
app.get('/Acadmicyear/:Acadmicyear', (request, response, next) => {

    let acadmicyear = request.params.Acadmicyear;

    acadmicyear = parseInt(acadmicyear);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {Acadmicyear:acadmicyear};


        //read from  collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});



//get students by Age - used in update and delete web pages
app.get('/Age/:Age', (request, response, next) => {

    let age = request.params.Age;

    age = parseInt(age);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {Age:age};


        //read from db collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});


//get students by CourseID - used in update and delete web pages
app.get('/CourseID /:CourseID ', (request, response, next) => {

    let CourseID  = request.params.CourseID ;


    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {CourseID:courseID};


        //read from db collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});


//get students by CourseName - used in update and delete web pages
app.get('/CourseName /:CourseName ', (request, response, next) => {

    let CourseName  = request.params.CourseName ;



    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");

        //build the query filter
        let query = {CourseName:courseName};


        //read from db collection
        srsDB.collection("tblstudent").find(query).toArray((err, itemsArray) => {
            if (err)
                console.log(err.message);

            response.send(JSON.stringify(itemsArray));
        });

        //close the connection to the db
        db.close();
    });
});



//###### INSERT
//#############################################################


//add a new Students - using HTTP POST method
app.post('/', (request, response, next) => {
   
    //access the form fields by the same names as in the HTML form

    let studentID = request.body.StudentID;
    const studentName = request.body.StudentName;
	const program = request.body.Program;
    const courseID = request.body.CourseID;
    const CourseName = request.body.CourseName;
    
    let acadmicyear = request.body.Acadmicyear;
    let age = request.body.Age;



    //convert 
    studentID = parseInt(studentID);
    acadmicyear = parseInt(acadmicyear);
    age = parseInt(age);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");
        
        const newStudent = {StudentID:studentID, StudentName:studentName, Program:program,
            Acadmicyear:acadmicyear,Age:age,CourseID:courseID,CourseName,courseName};

        //insert to   collection

        srsDB.collection("tblstudent").insertOne(newStudent, (err, result) => {
            if (err) {
                console.log(err.message);
            }

            if (result.insertedCount == 1) {

                //response.redirect("/static/index.html");
                response.end("student: " + studentName + " is added!!");
                
            }
            else
                response.end("student: " + studentName + " could not be added!!");
        });

        //close the connection to the db
        db.close();
    }); 
});



//###### UPDATE 
//#############################################################

//update Student - uisng HTTP PUT method
app.put('/', (request, response, next) => {
    
    console.log("in PUT");
    
    let studentID = request.param('StudentID');
    const studentName = request.param('StudentName');
	const program = request.param('Program');
    const courseID = request.param("CourseID");
    const courseName = request.param("CourseName");
    
    let acadmicyear = request.param('Acadmicyear');
    let age = request.param('Age');

    
    //convert to number
    studentID = parseInt(studentID);
    acadmicyear = parseInt(acadmicyear);
    age = parseInt(age);
    

 

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");
        
        //we are updating by the studentID
        const updateFilter = {StudentID:studentID};
        const updateValues = {$set:{StudentName:studentName,
            Program:program,Acadmicyear:acadmicyear,Age:age,CourseID:courseID,CourseName,courseName }};


        //insert from collection
        srsDB.collection("tblstudent").updateOne(updateFilter, updateValues, (err, res) => {
            if (err) {
                console.log(err.message);
            }
            //response.redirect("/static/index.html");
            response.end("student: " + studentName + " is updated!!");
            
           // response.send("<script>alert(\"student: " + studentName + " is updated!!\");</script>");
        });

        //close the connection to the db
        db.close();
    }); 
});

//###### DELETE 
//#############################################################


//delete a Student  by Student ID
app.delete('/', (request, response, next) => {
    
    
    let studentID = request.param('StudentID');
    studentID = parseInt(studentID);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            console.log("Cannot connect to Mongo:"+err.message);

        //connect to club
        const srsDB = db.db("srsDB");
        
        //we are deleting by the club_name
        const deleteFilter = {StudentID:studentID};

        //insert from footballdb club collection
        srsDB.collection("tblstudent").deleteOne(deleteFilter, (err, res) => {
            if (err) {
                console.log(err.message);
            }

            if (res.deletedCount > 0) {
                
                //response.redirect("/static/index.html");
                response.end("studentID: " + studentID + " is deleted!!");
            }
            else {
                response.send("<script>alert(\"deleted \" +studentID);</script>");
            }
        });

        //close the connection to the db
        db.close();
    }); 
});


//###### listen 


app.use('/static', express.static('public'));


//Evennode
//app.listen(process.env.PORT);
//console.log("server listening on Evennode");



const port = 7979;
app.listen(port, ()=> {
    console.log("server listening on "+port);
});
 

