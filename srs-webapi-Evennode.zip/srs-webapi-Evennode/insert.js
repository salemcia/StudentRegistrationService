const express = require('express');
//const cors = require('cors');
const mongoClient = require('mongodb').MongoClient;

const app = express();
//app.use(cors());




const mongoServerURL = "mongodb+srv://admin:admin@clustersrs.eulij.mongodb.net/srsDB?retryWrites=true&w=majority";




//###### INSERT
//#############################################################


//add a new Students - using HTTP POST method
app.post('/', (request, response, next) => {
   
    //access the form fields by the same names as in the HTML form

    let studentID = 321; 
    const studentName = "salem";
	const program = "IT";
    const courseID = "CIA";
    const CourseName ="Appkication Devoplemnt";
    
    let acadmicyear =4;
    let age = 23;



    //convert
   //// studentID = parseInt(studentID);
   // acadmicyear = parseInt(acadmicyear);
   // age = parseInt(age);

    mongoClient.connect(mongoServerURL, (err, db) => {
        if (err)
            response.end("Cannot connect to Mongo:"+err.message);

        //connect to db
        const srsDB = db.db("srsDB");
        
        const newStudent = {StudentID:studentID, StudentName:studentName, Program:program,
            Acadmicyear:acadmicyear,Age:age,CourseID:courseID,CourseName,courseName};

        //insert to   collection

        srsDB.collection("tblstudent").insertOne(newStudent, (err, result) => {
            if (err) {
                response.end(err.message);
            }

            if (result.insertedCount == 1) {

                //response.redirect("/static/index.html");
                response.end("student: " + studentName + " is added!!");
                
            }
            else
                response.end("student: " + studentName + " could not be added!!");
        });

        //close the connection to the db
        db.close();
    }); 
});


//###### listen 


//app.use('/static', express.static('public'));


//Evennode
//app.listen(process.env.PORT);
//console.log("server listening on Evennode");



const port = 7978;
app.listen(port, ()=> {
    console.log("server listening on "+port);
});
 

